<?php

$typeIdent = ['apple'=> [40, 50] , 'pear' => [0, 20]];


var_dump($typeIdent);